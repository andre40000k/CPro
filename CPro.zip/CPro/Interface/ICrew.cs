﻿namespace CPro_1.Interface
{
    public interface ICrew
    {
        int Crew { set; }
    }
}
