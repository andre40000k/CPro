﻿
namespace CPro_1.Interface
{
    public interface IGetInformation
    {
        //update ne inteface
        void ShowInfo();
    }
}
