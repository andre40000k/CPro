﻿namespace CPro_1.Interface
{
    public interface IGetSpeed
    {
        //update ne inteface
        double Speed { get; set; }
    }
}
