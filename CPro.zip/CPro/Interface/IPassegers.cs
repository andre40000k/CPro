﻿namespace CPro_1.Interface
{
    public interface IPassegers
    {
        int Passegers { set; }
    }
}
