﻿namespace CPro_1.Interface
{
    public interface IDistance
    {
        //update ne inteface
        void FinalDistance(double speed);
    }
}
