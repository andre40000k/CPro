﻿using CPro_1.Enums;
using CPro_1.Transports.TypeEngine;

namespace CPro_1.Interface
{
    public interface ITypeEngine
    {
        TypeEngineEnum TypeEngine { get; set; }
    }
}
