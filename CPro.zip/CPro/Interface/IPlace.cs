﻿namespace CPro_1.Interface
{
    public interface IPlace
    {
        //update ne inteface
        void InterestingPlaces();
    }
}
