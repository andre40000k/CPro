﻿namespace CPro_1.Interface
{
    public interface IPeapleInTransport
    {
        int NumPeople();
    }
}
