﻿using CPro_1.Transports.TypeEngine;

namespace CPro_1.Interface
{
    public interface IEngeen
    {
        public BaseEngine BaseEngine { get; init; }
    }
}
