﻿namespace CPro_1.Enums
{
    public enum TypeEngineEnum
    {
        ELECTRIC = 10,
        DVS = 12,
        GIBRID = 14
    }

    public enum ColorTypeEngineEnum
    {
        Green = 10,
        Red = 12,
        Yellow = 14        
    }

    public enum OpenCloseEnum
    {
        Open,
        Close
    }


}
