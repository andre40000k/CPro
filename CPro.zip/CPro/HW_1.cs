﻿using CPro_1.Helper;

namespace CPro
{
    internal class HW_1
    {
        static void Main(string[] args)
        {
            Helppppppp.RunScript();
        }
    }
}